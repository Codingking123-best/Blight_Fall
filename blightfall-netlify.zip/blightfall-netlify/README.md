# Blightfall Netlify Build

Deploy this folder to Netlify. It includes:

- `index.html` — the game.
- `netlify/functions/leaderboard.js` — online leaderboard API using Netlify Blobs.
- `netlify.toml` — Netlify publish/functions config.
- `package.json` — installs `@netlify/blobs`.

## Controls added

- The game starts directly without the dashboard menu.
- `Ctrl+Z` opens the code menu during play, pause, game over, or start.
- Enter `K!ngJ@mes` to unlock admin controls and all characters.
- Admin controls can edit/delete online leaderboard entries.
- `Ctrl+R` prevents browser refresh while in a run and immediately sends you to game over.

## Leaderboard behavior

Each display name has one online record. A new run only replaces that username's entry when the score is higher.

## Recommended Netlify setting

In Netlify Site settings → Environment variables, set:

`ADMIN_CODE=K!ngJ@mes`

You can change the environment variable later if you want a private code without editing the game.
