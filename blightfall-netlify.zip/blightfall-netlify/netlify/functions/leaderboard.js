import { getStore } from '@netlify/blobs';

const DEFAULT_ADMIN_CODE = 'K!ngJ@mes';
const BOARD_KEY = 'global-board-v1';
const MAX_ENTRIES = 50;

const json = (statusCode, body) => ({
  statusCode,
  headers: {
    'Content-Type': 'application/json',
    'Cache-Control': 'no-store',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
  },
  body: JSON.stringify(body)
});

function cleanName(name) {
  return String(name || 'Hunter').trim().replace(/\s+/g, ' ').slice(0, 24) || 'Hunter';
}

function keyForName(name) {
  return cleanName(name).toLowerCase();
}

function cleanEntry(entry = {}) {
  return {
    displayName: cleanName(entry.displayName),
    score: Math.max(0, Math.round(Number(entry.score || 0))),
    wave: Math.max(0, Math.round(Number(entry.wave || 0))),
    level: Math.max(0, Math.round(Number(entry.level || 0))),
    survivalSeconds: Math.max(0, Math.round(Number(entry.survivalSeconds || 0))),
    earnedShards: Math.max(0, Math.round(Number(entry.earnedShards || 0))),
    weapon: String(entry.weapon || 'Unknown').slice(0, 40),
    activeAbility: String(entry.activeAbility || 'Unknown').slice(0, 40),
    character: String(entry.character || 'Unknown').slice(0, 40),
    updatedAt: Number(entry.updatedAt || Date.now())
  };
}

function getStats(board) {
  const entries = Object.values(board.entries || {});
  const sorted = entries.sort((a, b) => (b.score || 0) - (a.score || 0));
  const top = sorted[0];
  return {
    totalRuns: Number(board.totalRuns || 0),
    postedBests: sorted.length,
    totalHunters: sorted.length,
    topScore: top ? Math.round(top.score || 0) : 0,
    topWave: top ? Math.round(top.wave || 0) : 0,
    bestHunter: top ? top.displayName : '—'
  };
}

function publicBoard(board) {
  const entries = Object.values(board.entries || {})
    .sort((a, b) => (b.score || 0) - (a.score || 0))
    .slice(0, MAX_ENTRIES);
  return { entries, stats: getStats(board) };
}

async function readBoard() {
  const store = getStore('blightfall-leaderboard');
  const board = await store.get(BOARD_KEY, { type: 'json' });
  return { store, board: board && typeof board === 'object' ? { totalRuns: 0, entries: {}, ...board } : { totalRuns: 0, entries: {} } };
}

async function saveBoard(store, board) {
  await store.setJSON(BOARD_KEY, board);
}

function assertAdmin(body) {
  const expected = process.env.ADMIN_CODE || DEFAULT_ADMIN_CODE;
  if (String(body?.adminCode || '') !== expected) {
    const error = new Error('Admin code rejected. Set ADMIN_CODE in Netlify or use the default development code.');
    error.statusCode = 403;
    throw error;
  }
}

export async function handler(event) {
  if (event.httpMethod === 'OPTIONS') return json(204, {});

  try {
    const { store, board } = await readBoard();

    if (event.httpMethod === 'GET') {
      return json(200, publicBoard(board));
    }

    if (event.httpMethod !== 'POST') {
      return json(405, { error: 'Method not allowed.' });
    }

    const body = JSON.parse(event.body || '{}');

    if (body.action === 'delete') {
      assertAdmin(body);
      delete board.entries[keyForName(body.displayName)];
      await saveBoard(store, board);
      return json(200, { ...publicBoard(board), deleted: true });
    }

    if (body.action === 'update') {
      assertAdmin(body);
      const originalKey = keyForName(body.originalDisplayName || body.entry?.displayName);
      const entry = cleanEntry(body.entry || {});
      if (body.originalDisplayName) delete board.entries[originalKey];
      board.entries[keyForName(entry.displayName)] = entry;
      await saveBoard(store, board);
      return json(200, { ...publicBoard(board), updated: true, admin: true });
    }

    const entry = cleanEntry(body);
    const entryKey = keyForName(entry.displayName);
    const previous = board.entries[entryKey];
    board.totalRuns = Number(board.totalRuns || 0) + 1;
    const isBetter = !previous || Number(entry.score || 0) > Number(previous.score || 0);
    if (isBetter) board.entries[entryKey] = entry;
    await saveBoard(store, board);
    return json(200, { ...publicBoard(board), updated: isBetter });
  } catch (error) {
    return json(error.statusCode || 500, { error: error.message || 'Leaderboard failed.' });
  }
}
